package com.cibertec.proyecto.Pedido

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto.R

class PedidoActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pedido_activity)
    }
}