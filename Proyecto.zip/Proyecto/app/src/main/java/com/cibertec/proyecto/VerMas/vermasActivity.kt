package com.cibertec.proyecto.vermasActivity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto.R

class vermasActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.vermas_activity)
    }
}