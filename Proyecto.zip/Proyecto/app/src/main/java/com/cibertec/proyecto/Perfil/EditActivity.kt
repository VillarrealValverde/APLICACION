package com.cibertec.proyecto.Perfil

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto.R

class EditActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.edit_activity)
    }
}