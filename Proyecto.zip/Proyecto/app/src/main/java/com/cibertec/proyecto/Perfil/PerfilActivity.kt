package com.cibertec.proyecto.Perfil

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto.R

class PerfilActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.perfil_activity)
    }
}