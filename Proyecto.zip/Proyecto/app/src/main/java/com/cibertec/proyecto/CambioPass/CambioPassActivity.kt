package com.cibertec.proyecto.CambioPass

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto.R

class CambioPassActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cambiarpass_activity)
    }
}